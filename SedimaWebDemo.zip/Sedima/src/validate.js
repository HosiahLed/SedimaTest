var ErrName = document.getElementById('name-err');
var ErrSurname = document.getElementById('surname-err');
var ErrEmail = document.getElementById('email-err');
var ErrPhone = document.getElementById("phone-err");
var ErrVehicle = document.getElementById('vehicle-err');
var ErrAdults = document.getElementById('adults-err');
var ErrChildren = document.getElementById('kids-err');
var ErrSubmit = document.getElementById('submit-err');

function validateName(){

    var names = document.getElementById('names').value;

    if(names.length == 0){
        ErrName.innerHTML = 'Name is required';
        return false;
    }

    if(!names.match(/^[A-Za-z\s]+$/)){
        ErrName.innerHTML = '<i class="fa-solid fa-circle-xmark" style = "color: #e60000"></i>';
        return false;
    }

    ErrName.innerHTML = '<i class="fas fa-check-circle"></i>';
    return true;
} 

function validateSurname() {
    var surname = document.getElementById('surname').value;

    if (surname.length === 0) {
        ErrSurname.innerHTML = 'Surname is required';
        return false;
    }

    if (!surname.match(/^[A-Za-z\s]+$/)) {
        ErrSurname.innerHTML = '<i class="fa-solid fa-circle-xmark" style = "color: #e60000"></i>';
        return false;
    }

    ErrSurname.innerHTML = '<i class="fas fa-check-circle"></i>';
    return true;
}

function validateEmail(){

    var email = document.getElementById('email').value;

    if(email.length == 0){
        ErrEmail.innerHTML = 'Email is required'
        return false;
    }

    let pattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (!email.match(pattern)) {
        ErrEmail.innerHTML = '<i class="fa-regular fa-envelope" style = "color: #e60000"></i>'
        return false;
    }else{
            ErrEmail.innerHTML = '<i class="fa-regular fa-envelope"></i>'
            return true;
        }

}